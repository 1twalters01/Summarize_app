Moderation microservice written in python.

# Why Python
* 

# Overview
* Handles reporting
* Admin can review claims
* Check for piracy

# Details
* 
